"""
https://contest.yandex.ru/contest/22781/run-report/115387752/

-- ПРИНЦИП РАБОТЫ --
Реализован дек (двустороннюю очередь) на массиве фиксированного размера
с двумя указателями: head и tail.
Элементы могут добавляться и извлекаться с обеих сторон дека.
При реализации используется кольцевой буфер.

При реализации кольцевого буфера используется операция
взятия остатка от деления на размер массива.

При добавлении и удалении элементов в дек указатели head и tail
обновляются и циклически перемещаются по массиву, не выходя за его пределы.
При добавлении элемента в начало очереди указатель head перемещается влево,
и затем ячейка, на которую указывает head, заполняется новым значением.
При извлечении элемента с «головы» очереди в консоль выводится элемент,
на который указывается указатель head.
Значение текущей ячейки заменяется на None
и указатель head смещается на одно значение вправо.
Таким образом мы сохраняем возможность
получить элемент с «головы» очереди и не «затереть» его новым значением.
При добавлении элемента в конец очереди
новый элемент добавляется в соответствующую пустую ячейку, на которую указывает tail,
а затем указатель сдвигается вправо на следующую пустую ячейку.
При извлечении элемента с «хвоста» очереди указатель tail
смещается на одно значение влево на последнюю заполненную ячейку,
значение ячейки выводится в консоль и заменяется на None.

-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --
Корректность работы алгоритма обеспечивается
благодаря управлению указателями head и tail,
которые всегда остаются в пределах массива,
что достигается применением операция взятия остатка от деления на размер массива.
Когда массив заполнен — размер очереди равен максимальному,
при попытке добавления элементов выводится сообщение об ошибке.
Если очередь пуста, при попытке извлечения элементов
также выводится сообщение об ошибке.
Таким образом, корректность работы алгоритма
обеспечивается проверками размера и обновлением указателей.

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Добавление и извлечение элементов с обеих сторон дека
осуществляется за O(1), так как операции включают
только обновление указателей и присваивание значений в массиве.
Все проверки размера очереди и обновления указателей происходят за константное время.

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --
Пространственная сложность дека составляет O(n),
где n - размер фиксированного массива.
Дополнительно необходимо хранить переменные указателей и размера массива,
которыми можно пренебречь.
"""


class Deque:

    def __init__(self, n):
        self.deque = [None] * n
        self.head = 0
        self.tail = 0
        self.size = 0
        self.maximum_number_of_items = n

    def push_back(self, x):
        if self.size == self.maximum_number_of_items:
            raise OverflowError()
        self.deque[self.tail] = x
        self.tail = (self.tail + 1) % self.maximum_number_of_items
        self.size += 1

    def push_front(self, x):
        if self.size == self.maximum_number_of_items:
            raise OverflowError()
        self.head = (self.head - 1) % self.maximum_number_of_items
        self.deque[self.head] = x
        self.size += 1

    def pop_back(self):
        if self.size == 0:
            raise IndexError()
        else:
            self.tail = (self.tail - 1) % self.maximum_number_of_items
            x = self.deque[self.tail]
            self.deque[self.tail] = None
            self.size -= 1
            return x

    def pop_front(self):
        if self.size == 0:
            raise IndexError()
        else:
            x = self.deque[self.head]
            self.deque[self.head] = None
            self.head = (self.head + 1) % self.maximum_number_of_items
            self.size -= 1
            return x


def read_input():
    n = int(input().strip())
    m = int(input().strip())
    method_names = []
    deque = Deque(m)

    while n > 0:
        method_names.append(input().strip())
        n -= 1

    for i in method_names:
        try:
            if ' ' in i:
                method_name, parameter = i.split()
                parameter = int(parameter)
                method = getattr(deque, method_name)
                method(parameter)
            else:
                method = getattr(deque, i)
                print(method())
        except (IndexError, OverflowError):
            print('error')


if __name__ == '__main__':
    read_input()
